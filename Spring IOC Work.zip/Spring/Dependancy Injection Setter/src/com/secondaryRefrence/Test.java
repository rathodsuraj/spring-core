package com.secondaryRefrence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext ap=new ClassPathXmlApplicationContext("secondaryreff.xml");
		Employee emp=(Employee)ap.getBean("employee");
		System.out.println(emp.getEid());
		System.out.println(emp.getName());
		System.out.println(emp.getAddr().getAreaname());
		System.out.println(emp.getAddr().getCity());
	}

}

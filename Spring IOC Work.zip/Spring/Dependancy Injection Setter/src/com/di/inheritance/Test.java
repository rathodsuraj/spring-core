package com.di.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("inheritance.xml");

		Class c = (Class) ap.getBean("class");

		System.out.println(c.getName());
		System.out.println(c.getRollno());
		System.out.println(c.getAddress());
		System.out.println(c.getCname());
		System.out.println(c.getCaddress());

	}

}

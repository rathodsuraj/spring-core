package com.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext ap = new ClassPathXmlApplicationContext("web.xml");
		Student s = (Student) ap.getBean("4 ");
		System.out.println("name is "+s.getName());
		System.out.println("rollno id "+s.getRollno());
		System.out.println("address is "+s.getAddress());

	}

}

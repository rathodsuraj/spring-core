package com.di.array.secondary;

public class Employee {

	private int empid;
	private String empname;
	Mobile mobile[];

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public Mobile[] getMobile() {
		return mobile;
	}

	public void setMobile(Mobile[] mobile) {
		this.mobile = mobile;
	}

}

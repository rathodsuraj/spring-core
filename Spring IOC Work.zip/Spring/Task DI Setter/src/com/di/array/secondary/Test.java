package com.di.array.secondary;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("arraysecondary.xml");
		Employee emp = (Employee) apc.getBean("emp");
		System.out.println("emp id is " + emp.getEmpid());
		System.out.println("emp name is " + emp.getEmpname());

		Mobile[] arr = emp.getMobile();

		for (int i = 0; i < arr.length; i++) {
			System.out.println("mobile no are" + arr[i].getMobno());
		}
	}

}

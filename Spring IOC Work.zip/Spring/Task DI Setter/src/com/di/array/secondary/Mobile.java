 package com.di.array.secondary;

public class Mobile {

	private String mobno;

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	
}

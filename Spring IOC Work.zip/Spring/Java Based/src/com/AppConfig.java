package com;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class AppConfig {
	@Bean(name = "s1")
	public Student s() {
		Student st=new Student();
		st.setId(23);
		st.setName("suraj");
		st.setAddress(addr());
		return st;
	}
	@Bean
	public Address addr() {
		Address add=new Address();
		add.setAreaname("warje");
		add.setCityname("pune");
		return add;
	}

}

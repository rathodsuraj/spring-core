package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Student stu = apc.getBean("s1", Student.class);

		Address adr = apc.getBean("addr", Address.class);

		System.out.println(stu);
		System.out.println(stu.getId());
		System.out.println(stu.getName());
		System.out.println("==========");
		System.out.println(adr.getAreaname());
		System.out.println(adr.getCityname());
		System.out.println("===========");
		System.out.println(stu.getId());
		System.out.println(stu.getName());
		System.out.println(stu.getAddress().getAreaname());
		System.out.println(stu.getAddress().getCityname());

	}

}

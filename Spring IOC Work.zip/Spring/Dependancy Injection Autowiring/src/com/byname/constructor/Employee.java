package com.byname.constructor;

public class Employee {
	private int empid;
	private String empname;
	Company company;
	public Employee(int empid, String empname, Company company) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", company=" + company + "]";
	}
	

}

package com.byname.constructor;

public class Company {
	private String companyname;
	private int capacity;

	public Company(String companyname, int capacity) {
		super();
		this.companyname = companyname;
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Company [companyname=" + companyname + ", capacity=" + capacity + "]";
	}

}

package com.byname.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext apc=new ClassPathXmlApplicationContext("bynameconst.xml");
	Employee emp=apc.getBean("employe",Employee.class);
		System.out.println(emp);
		
	}
}

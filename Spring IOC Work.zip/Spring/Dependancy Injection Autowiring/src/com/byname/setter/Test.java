package com.byname.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext apc=new ClassPathXmlApplicationContext("byname.xml");
		Student s=apc.getBean("stu",Student.class);
		System.out.println("------------");
		System.out.println(s.getRollno());
		System.out.println(s.getName());
		System.out.println(s.getAddr().getAreaname());
		System.out.println(s.getAddr().getCityname());
	}

}

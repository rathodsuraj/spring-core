package com.bytype.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("bytype.xml");
		
	Employee emp=(Employee)apc.getBean("emp");
		System.out.println(emp.getEid());
		System.out.println(emp.getEname());
		System.out.println(emp.getCmp().getAreaname());
		System.out.println(emp.getCmp().getCityname());
	}
}

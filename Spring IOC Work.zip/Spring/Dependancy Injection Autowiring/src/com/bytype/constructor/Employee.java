package com.bytype.constructor;

public class Employee {
	private int eid;
	private String ename;
	Company company;
	public Employee(int eid, String ename, Company company) 
	{
		this.eid = eid;
		this.ename = ename;
		this.company = company;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", company=" + company + "]";
	}
	
	

}

package com.bytype.constructor;

public class Company {

	private String areaname;
	private String cityname;

	public Company(String areaname, String cityname) 
	{
		this.areaname = areaname;
		this.cityname = cityname;
	}

	@Override
	public String toString() {
		return "Company [areaname=" + areaname + ", cityname=" + cityname + "]";
	}

}

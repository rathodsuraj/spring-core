package com.primitive.array;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		
	ApplicationContext apc=new AnnotationConfigApplicationContext(AppConfig.class);
	
	Employee emp=apc.getBean("emp",Employee.class);
		
	System.out.println(emp.getId());
	System.out.println(emp.getName());
	int [] arr=emp.getMobile();
	
	for (int i = 0; i < arr.length; i++) {
		System.out.println(arr[i]);
	}
	}

}

package com.primitive.array;

public class Employee {
	
	private int id;
	private String name;
	private int []Mobile;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getMobile() {
		return Mobile;
	}
	public void setMobile(int[] mobile) {
		Mobile = mobile;
	}
	
	

}

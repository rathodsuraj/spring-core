package com.primitive.array;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
@Bean
	public Employee emp() {

		Employee emp = new Employee();

		emp.setId(23);
		emp.setName("suraj");
		int[] arr = { 988889,233422,544566,323455,23345 };
		emp.setMobile(arr);
		return emp;
	}

}

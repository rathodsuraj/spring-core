package com.primitive.collection.constructor;
import java.util.*;
public class Student {
	
	private List mylist;
	private Set myset;
	private Map mymap;
	public Student(List mylist, Set myset, Map mymap) {
		super();
		this.mylist = mylist;
		this.myset = myset;
		this.mymap = mymap;
	}
	@Override
	public String toString() {
		return "Student [mylist=" + mylist + ", myset=" + myset + ", mymap=" + mymap + "]";
	}
	
	
	
	

}

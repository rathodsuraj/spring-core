package com.primitive.collection.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		
		ApplicationContext apc=new AnnotationConfigApplicationContext(AppConfig.class);
	Student stu=apc.getBean("s1",Student.class);
	
	System.out.println(stu);
	}

}

package com.primitive.collection.constructor;

import java.util.*;

import org.springframework.context.annotation.Bean;

public class AppConfig {
@Bean
	public Student s1() {
		List mylist = new ArrayList();
		mylist.add(23);
		mylist.add(67);

		Set myset = new HashSet();
		myset.add(45);
		myset.add(46);

		Map mymap = new HashMap();

		mymap.put(1, "suraj");
		mymap.put(2, "akash");

		Student stu = new Student(mylist, myset, mymap);

		return stu;
	}

}

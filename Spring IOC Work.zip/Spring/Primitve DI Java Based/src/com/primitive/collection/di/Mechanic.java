package com.primitive.collection.di;
import java.util.*;
public class Mechanic {
	
	private List mylist;
	private Set myset;
	private Map map;
	public List getMylist() {
		return mylist;
	}
	public void setMylist(List mylist) {
		this.mylist = mylist;
	}
	public Set getMyset() {
		return myset;
	}
	public void setMyset(Set myset) {
		this.myset = myset;
	}
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	

}

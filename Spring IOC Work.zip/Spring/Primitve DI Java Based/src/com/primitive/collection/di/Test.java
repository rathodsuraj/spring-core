package com.primitive.collection.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		
		ApplicationContext apc=new AnnotationConfigApplicationContext(AppConfig.class);
	Mechanic mech=apc.getBean("m",Mechanic.class);
	
	List li=mech.getMylist();
	Set set=mech.getMyset();
	Map map=mech.getMap();
	System.out.println(li);
	System.out.println(set);
	System.out.println(map);
	
	for(Object l:li) {
		System.out.println(l);
	}
	System.out.println("set");
	for(Object s:set) {
		System.out.println(s);
	}
	
	Set keys=map.keySet();
	for(Object key:keys) {
		String value=(String) map.get(key);
		System.out.println(value);
	}
	}
}

package com.primitive.collection.di;

import org.springframework.context.annotation.Bean;
import java.util.*;

public class AppConfig {
	@Bean
	public Mechanic m() {

		Mechanic mech = new Mechanic();

		List li = new ArrayList();
		li.add(34);
		li.add(45);
		li.add("suraj");
		mech.setMylist(li);

		Set set = new HashSet();
		set.add(12);
		set.add(34);
		set.add(54);
		mech.setMyset(set);

		Map map = new HashMap();
		map.put(23, "suraj");
		map.put(24, "akash");
		map.put(34, "swapnil");
		mech.setMap(map);

		return mech;
	}

}

package com.constructor.array;

import java.util.Arrays;

public class Student {
	
	private int id;
	private String name;
	private int [] mob;

	public Student(int id, String name, int[] mob) {
		this.id = id;
		this.name = name;
		this.mob = mob;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", mob=" + Arrays.toString(mob) + "]";
	}
	
	
	

}

package com.constructor.array;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class AppConfig {
	@Bean (name = "arraysecondary")
	public Student student() {
		int[] arr = { 2, 3, 4, 5, 5, 6, 8 };
		Student st = new Student(34, "suraj", arr);
		return st;
	}

}

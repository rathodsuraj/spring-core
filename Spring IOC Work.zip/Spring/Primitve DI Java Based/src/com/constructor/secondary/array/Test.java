package com.constructor.secondary.array;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Student stu = apc.getBean("secondaryarray", Student.class);
		System.out.println(stu.getSid());
		System.out.println(stu.getName());

		Mobile[] arr = stu.getMob();

		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i].getMob());
		}

	}
}

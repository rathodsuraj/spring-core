package com.constructor.secondary.array;

import org.springframework.context.annotation.Bean;

public class AppConfig {
	@Bean(name="secondaryarray")
	public Student student() {
		
		Mobile [] mob= {mob1(),mob2()};
		
		Student stu=new Student(34,"suraj", mob);
		
		return stu;
	}
	
	public Mobile mob1() {
		
		Mobile mob=new Mobile(78773);
		return mob;
	}
	public Mobile mob2() {
		Mobile mob=new Mobile(989948);
		return mob;
	}

}

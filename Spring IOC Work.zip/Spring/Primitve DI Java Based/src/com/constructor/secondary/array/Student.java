package com.constructor.secondary.array;

public class Student {
	
	private int sid;
	private String name;
	Mobile[] mob;
	public Student(int sid, String name, Mobile[] mob) {
		super();
		this.sid = sid;
		this.name = name;
		this.mob = mob;
	}
	public int getSid() {
		return sid;
	}
	public String getName() {
		return name;
	}
	public Mobile[] getMob() {
		return mob;
	}
	
	

}

package com.constructor.secondary.array;

public class Mobile {
	
	private long mob;

	public Mobile(long mob) {
		this.mob = mob;
	}

	public long getMob() {
		return mob;
	}
	
	
	
	

}

package com.secondary.array;

public class Mobile {
	
	private long mob;

	public long getMob() {
		return mob;
	}

	public void setMob(long mob) {
		this.mob = mob;
	}
	
	
	

}

package com.secondary.array;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		
		
		ApplicationContext apc=new AnnotationConfigApplicationContext(AppConfig.class);
		Student stu=apc.getBean("array",Student.class);
		System.out.println(stu.getSid());
		System.out.println(stu.getName());
		
		Mobile[] mob=stu.getMob();
		
		for (int i = 0; i < mob.length; i++) {
			System.out.println(mob[i].getMob());
		}

	}

}

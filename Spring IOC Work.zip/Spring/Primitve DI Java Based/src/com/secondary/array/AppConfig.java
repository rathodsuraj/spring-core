package com.secondary.array;

import org.springframework.context.annotation.Bean;

public class AppConfig {
	@Bean(name = "array")
	public Student stu() {
		Student st = new Student();
		st.setSid(34);
		st.setName("vallabh");

		Mobile[] mob = {mob(),mob1(),mob2()};

		st.setMob(mob);
		return st;
	}

	@Bean
	public Mobile mob() {
		Mobile mobile1 = new Mobile();
		mobile1.setMob(787787773);
		return mobile1;
	}
	public Mobile mob1() {
		Mobile mobile2=new Mobile();
		mobile2.setMob(87887773);
		return mobile2;
	}
	public Mobile mob2() {
		Mobile mobile3=new Mobile();
		mobile3.setMob(877887773);
		return mobile3;
	}

}

package com.secondary.constructor.di;

public class Address {
	
	private String cityname;
	private String areaname;
	
	public Address(String cityname,String areaname) {
		
		this.cityname=cityname;
		this.areaname=areaname;
	}

	@Override
	public String toString() {
		return "Address [cityname=" + cityname + ", areaname=" + areaname + "]";
	}

	
}

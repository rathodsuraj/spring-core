package com.secondary.constructor.di;

import org.springframework.context.annotation.Bean;

public class AppConfig {
	@Bean
	public Student s() {
		
		Student stu=new Student(1,"suraj",addr());
		return stu;
	}	
	@Bean
	public Address addr() {
		
		Address add=new Address("pune", "warje");
		return add;
	}

}

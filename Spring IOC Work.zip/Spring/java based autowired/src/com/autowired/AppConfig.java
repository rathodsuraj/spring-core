package com.autowired;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Student student() {
		Student stu=new Student();
		stu.setSid(23);
		stu.setName("swapnil");
		return stu;
	}
	
	@Bean
	public Address address() {
		Address addr=new Address();
		addr.setAreaname("four bunglow");
		addr.setCityname("Andheri");
		return addr;
	}
	
	

}

package com.spring;

public class Oracle implements Connection {
	
	public Oracle() {
		System.out.println("Oracle construstor");
		
	}

	@Override
	public void commit() {

		System.out.println("commit ===Oracle");

	}

	@Override
	public void rollback() {

		System.out.println("rollback ====Oracle");
	}

}

package com.spring;

public class MySql implements Connection{

	public MySql() {
		System.out.println("mysql constructor");
	}
	@Override
	public void commit() {
		
		System.out.println("commit Mysql");
		
	}

	@Override
	public void rollback() {
		
		System.out.println("rollback Mysql");
		
	}

	
}

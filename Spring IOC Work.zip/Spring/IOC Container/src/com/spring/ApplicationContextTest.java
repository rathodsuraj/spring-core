package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationContextTest {

	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("web.xml");

		Connection c = (Connection) ap.getBean("con");
		c.commit();
		c.rollback();
	//	System.out.println("Hashcode:=="+c);
		
		Connection cc = (Connection) ap.getBean("con");
		cc.commit();
		cc.rollback();
	//	System.out.println("Hashcode:=="+cc);


	}

}

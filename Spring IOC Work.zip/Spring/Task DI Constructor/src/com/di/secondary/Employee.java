package com.di.secondary;

public class Employee {
	private int empid;
	private String empname;
	Mobile[] mob;
	
	public Employee(int empid,String empname,Mobile[] mob) {
		
		this.empid=empid;
		this.empname=empname;
		this.mob=mob;
	}

	public int getEmpid() {
		return empid;
	}

	public String getEmpname() {
		return empname;
	}

	public Mobile[] getMob() {
		return mob;
	}

}

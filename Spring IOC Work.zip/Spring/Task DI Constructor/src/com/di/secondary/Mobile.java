package com.di.secondary;

public class Mobile {
	
	private String mobno;
	
	public Mobile(String mobno) {
		
		this.mobno=mobno;
	}

	public String getMobno() {
		return mobno;
	}
	

}

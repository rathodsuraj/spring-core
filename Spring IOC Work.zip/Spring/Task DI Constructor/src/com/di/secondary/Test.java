package com.di.secondary;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("secondary.xml");
		Employee emp = (Employee) apc.getBean("emp");
		System.out.println(emp.getEmpid());
		System.out.println(emp.getEmpname());
		Mobile[] mob = emp.getMob();
		for (int i = 0; i < mob.length; i++) {

			System.out.println("mobile number are:" + mob[i].getMobno());

		}
	}

}

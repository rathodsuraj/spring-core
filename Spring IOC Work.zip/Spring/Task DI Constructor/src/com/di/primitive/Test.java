package com.di.primitive;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("primitive.xml");
		Employee e = apc.getBean("emp", Employee.class);
		System.out.println(e.getEmpid());
		System.out.println(e.getEmpname());
		String[] arr = e.getMobileno();
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}

	}

}

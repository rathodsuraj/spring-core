package com.di.primitive;

public class Employee {
	private int empid;
	private String empname;
	private String mobileno[];
	
	public Employee(int empid, String empname, String mobileno[]) {
	
	this.empid=empid;
	this.empname=empname;
	this.mobileno=mobileno;
	
	}
	
	
	
	public int getEmpid() {
		return empid;
	}
	public String getEmpname() {
		return empname;
	}
	public String[] getMobileno() {
		return mobileno;
	}
	

}

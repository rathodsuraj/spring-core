package com.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;

public class Test {

	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("collection.xml");
		Student s = apc.getBean("stu", Student.class);

		List<String> list = s.getMylist();
		Set<String> set = s.getMyset();
		Map<Integer, String> map = s.getMymap();

		Iterator<String> itr = list.iterator();
		while (itr.hasNext()) {
			String s1 = itr.next();
			System.out.println(s1);
		}

		Set<Integer> keys = map.keySet();
		Iterator<Integer> itr1 = keys.iterator();
		while (itr1.hasNext()) {
			int key = (Integer) itr1.next();
			String value = map.get(key);
			System.out.println(key);
			System.out.println(value);
		}

		Iterator<String> itr2 = set.iterator();
		while (itr2.hasNext()) {
			String stu = itr2.next();
			System.out.println(stu);

		}

		System.out.println(list);
		System.out.println(set);
		System.out.println(map);

	}

}

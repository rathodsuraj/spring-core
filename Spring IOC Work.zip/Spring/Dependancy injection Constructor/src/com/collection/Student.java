package com.collection;

import java.util.*;

public class Student {
	private List mylist;
	private Set myset;
	private Map<Integer, String> mymap;

	public Map<Integer, String> getMymap() {
		return mymap;
	}

	public void setMymap(Map<Integer, String> mymap) {
		this.mymap = mymap;
	}

	public List getMylist() {
		return mylist;
	}

	public void setMylist(List mylist) {
		this.mylist = mylist;
	}

	public Set getMyset() {
		return myset;
	}

	public void setMyset(Set myset) {
		this.myset = myset;
	}

	
}

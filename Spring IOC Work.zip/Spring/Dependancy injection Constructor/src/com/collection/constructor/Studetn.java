package com.collection.constructor;

import java.util.*;

public class Studetn {
	private List<Integer> list;
	private Set<String> set;
	private Map<Integer, String> map;

	public Studetn(List<Integer> list, Set<String> set, Map<Integer, String> map) {

		this.list = list;
		this.set = set;
		this.map = map;
	}

	public List<Integer> getList() {
		return list;
	}

	public Set<String> getSet() {
		return set;
	}

	public Map<Integer, String> getMap() {
		return map;
	}

}

package com.collection.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("collcons.xml");
		Studetn s = apc.getBean("student", Studetn.class);
		List list = s.getList();
		Set set = s.getSet();
		Map map = s.getMap();
		System.out.println(list + " " + set + " " + map);
	}

}

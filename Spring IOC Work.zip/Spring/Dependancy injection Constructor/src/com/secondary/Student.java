package com.secondary;

public class Student {
	private int sid;
	private String name;
	Classs cs;

	public Student(int sid,String name,Classs cs) {
		
		this.sid=sid;
		this.name=name;
		this.cs=cs;
	}
	
	@Override
	public String toString() {
	
		return "stu id"+sid+" stu name"+name;
		
	}
	
}

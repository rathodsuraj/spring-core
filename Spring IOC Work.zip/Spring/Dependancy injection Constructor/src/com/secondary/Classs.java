package com.secondary;

public class Classs {
	
	private int cid;
	private String cname;
	
	public Classs(int cid,String cname) {
		
		this.cid=cid;
		this.cname=cname;
	}
	@Override
	public String toString() {
		return "cid "+cid+" cname "+cname;
	}
}

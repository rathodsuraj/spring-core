package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("constructor.xml");
		System.out.println(apc);
		Studdent s = apc.getBean("stu", Studdent.class);
		System.out.println(s);

		/*
		 * System.out.println(s.getId()); System.out.println(s.getName());
		 */

	}

}

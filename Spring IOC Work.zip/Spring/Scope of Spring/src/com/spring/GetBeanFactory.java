package com.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class GetBeanFactory {

	public static void main(String[] args) {

		Resource rs = new ClassPathResource("web.xml");
		BeanFactory bf = new XmlBeanFactory(rs);
		 Connection c=(Connection)bf.getBean("con");
		// System.out.println(c);

		// c.commit();
		// c.rollback();

		 Connection c1=(Connection)bf.getBean("conn");

		// System.out.println(c1);
	}

}

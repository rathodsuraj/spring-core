package com.spring;

public class Oracle implements Connection {

	public Oracle() {

		System.out.println("Constructor of Oracle");
	}

	@Override
	public void commit() {
		System.out.println("commit==Oracle");
	}

	@Override
	public void rollback() {
		System.out.println("rollback0==Oracle");
	}

}

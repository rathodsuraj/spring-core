package com.wcs.spring.lookupmehtod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("bean.xml");

		Student stu = apc.getBean("student", Student.class);
		System.out.println(stu);
		Address addr = apc.getBean("address", Address.class);
		System.out.println(addr);

		stu = apc.getBean("student", Student.class);
		System.out.println(stu);
		addr = apc.getBean("address", Address.class);
		System.out.println(addr);

		stu = apc.getBean("student", Student.class);
		System.out.println(stu);
		addr = apc.getBean("address", Address.class);
		System.out.println(addr);
	}

}

package com.wcs.spring.lookupmehtod;

public class Address {
	private String name;
	
	public Address() {
		
		System.out.println("constructor of address");
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}

package com.wcs.spring.lookupmehtod;

public class Student {
private int id;
private Address address;

public Student() {
	
	System.out.println("Constructor of student");
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}

}

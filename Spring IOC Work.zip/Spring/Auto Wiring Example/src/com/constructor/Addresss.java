package com.constructor;

public class Addresss {

	private String cityname, areaname;

	public Addresss(String cityname, String areaname) {
		super();
		this.cityname = cityname;
		this.areaname = areaname;
	}

	@Override
	public String toString() {
		return "Addresss [cityname=" + cityname + ", areaname=" + areaname + "]";
	}

}

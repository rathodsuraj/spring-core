package com.constructor;

public class Employeee {

	private int eid;
	private String ename;
	private Addresss eadr;
	public Employeee(int eid, String ename, Addresss eadr) 
	{
		this.eid = eid;
		this.ename = ename;
		this.eadr = eadr;
	}
	@Override
	public String toString() {
		return "Employeee [eid=" + eid + ", ename=" + ename + ", eadr=" + eadr + "]";
	}
	
	
	
}

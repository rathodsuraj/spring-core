package com.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Testt {

	public static void main(String[] args) {
		ApplicationContext apc = new ClassPathXmlApplicationContext("new.xml");
		Employeee emp = apc.getBean("employe", Employeee.class);
		Studentt stu = apc.getBean("student", Studentt.class);
		System.out.println("employee details:");
		System.out.println(emp);
		System.out.println("Student detail:");
		System.out.println(stu);
	}

}

package com.constructor;

public class Studentt {
	
	private int sid;
	private String sname;
	private Addresss sadr;
	public Studentt(int sid, String sname, Addresss sadr) {
		this.sid = sid;
		this.sname = sname;
		this.sadr = sadr;
	}
	@Override
	public String toString() 
	{
		return "Studentt [sid=" + sid + ", sname=" + sname + ", sadr=" + sadr + "]";
	}
	
	
	
	
	
	

}

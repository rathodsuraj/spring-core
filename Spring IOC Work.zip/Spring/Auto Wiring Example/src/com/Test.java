package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {

		ApplicationContext apc = new ClassPathXmlApplicationContext("bean.xml");
		System.out.println(apc);
		Employee emp = apc.getBean("employe", Employee.class);
		Student stu = apc.getBean("stu", Student.class);
		
		System.out.println("Employee Details");
		System.out.println(emp.getEid());
		System.out.println(emp.getEname());
		System.out.println(emp.getAadr().getCityname());
		
		System.out.println("student details");
		System.out.println(stu.getId());
		System.out.println(stu.getName());
		System.out.println(stu.getSadr().getCityname() );
		
		/*
		 * System.out.println("Student Details"); System.out.println(stu.getId());
		 * System.out.println(stu.getName());
		 * System.out.println(stu.getSadr().getCityname());
		 */
	}

}
